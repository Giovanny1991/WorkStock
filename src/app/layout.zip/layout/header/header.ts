import {
  Component,
  EventEmitter,
  inject,
  Input,
  Output
} from '@angular/core';

import {
  Router
} from '@angular/router';

import {
  MatToolbarModule
} from '@angular/material/toolbar';

import {
  MatButtonModule
} from '@angular/material/button';

import {
  MatIconModule
} from '@angular/material/icon';

import {
  MatMenuModule
} from '@angular/material/menu';

import {
  AuthService
} from '../../core/auth/auth.service';


@Component({

  selector:
    'app-header',

  standalone:
    true,

  imports: [

    MatToolbarModule,

    MatButtonModule,

    MatIconModule,

    MatMenuModule

  ],

  templateUrl:
    './header.html',

  styleUrl:
    './header.scss'

})
export class Header {


  // =====================================================
  // TEMA
  // =====================================================

  @Input()
  tema:
    'light'
    |
    'dark' =
    'light';


  @Output()
  cambiarTema =
    new EventEmitter<void>();


  // =====================================================
  // MENÚ
  // =====================================================

  @Output()
  menuClick =
    new EventEmitter<void>();


  // =====================================================
  // SERVICIOS
  // =====================================================

  readonly authService =
    inject(
      AuthService
    );


  readonly esSuperAdmin =
    this.authService.esSuperAdmin;


  private readonly router =
    inject(
      Router
    );


  // =====================================================
  // MENÚ
  // =====================================================

  toggleMenu():
    void {

    this.menuClick.emit();

  }


  // =====================================================
  // CERRAR SESIÓN
  // =====================================================

  cerrarSesion():
    void {

    this.authService
      .logout()

      .subscribe({

        next:
          () => {

            this.router.navigate([
              '/login'
            ]);

          },


        error:
          () => {

            this.authService
              .limpiarSesion();


            this.router.navigate([
              '/login'
            ]);

          }

      });

  }

}